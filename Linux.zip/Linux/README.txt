#!/bin/bash
#   IMPORTANT!
#
#   Only install Defender on (standalone) computers owned by Aalto University!
#
# Installation on ubuntu:
# copy this directory and it's contents to the standalone Ubuntu and run these commands as root or with sudo
# (or execute this README file as a bash script..)
# scp -r username@kosh.aalto.fi:/m/work/common/media/Microsoft/DefenderForEndpoint/Linux . && cd Linux/
#
# Add Microsoft repository:
curl -o /etc/apt/sources.list.d/microsoft.list https://packages.microsoft.com/config/ubuntu/$(lsb_release -sr)/prod.list
# supposing we are on amd64 and not on arm...
sed -i 's/\[arch=.*\]/[arch=amd64]/' /etc/apt/sources.list.d/microsoft.list
chown root:root /etc/apt/sources.list.d/microsoft.list
chmod 644 /etc/apt/sources.list.d/microsoft.list
# download ms repository key
curl -sSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null
chown root:root /etc/apt/trusted.gpg.d/microsoft.gpg
chmod 644 /etc/apt/trusted.gpg.d/microsoft.gpg
# configure apt to only install mdatp from ms repository
cp mdatp.pref /etc/apt/preferences.d/.
chown root:root /etc/apt/preferences.d/mdatp.pref
chmod 644 /etc/apt/preferences.d/mdatp.pref
# install mdatp package
apt update && apt -y install mdatp

# onboard and configure mdatp
python3 MicrosoftDefenderATPOnboardingLinuxServer.py
cp mdatp_managed.json /etc/opt/microsoft/mdatp/managed/.
chown root:root /etc/opt/microsoft/mdatp/managed/mdatp_managed.json
chmod 644 /etc/opt/microsoft/mdatp/managed/mdatp_managed.json
# restart mdatp
systemctl restart mdatp.service

# schedule weekly scans
cp mdatp_scheduled /etc/cron.d/.
chown root:root /etc/cron.d/mdatp_scheduled
chmod 644 /etc/cron.d/mdatp_scheduled
# MS Documentation:
# https://learn.microsoft.com/en-us/microsoft-365/security/defender-endpoint/linux-install-manually?view=o365-worldwide

